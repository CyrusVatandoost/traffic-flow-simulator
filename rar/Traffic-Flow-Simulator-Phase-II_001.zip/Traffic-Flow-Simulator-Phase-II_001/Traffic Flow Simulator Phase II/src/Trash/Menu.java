import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.ImageIcon;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

public class Menu extends JPanel implements ActionListener{

	Simulation s = new Simulation();
	JButton b1, b2, b3, b4;
	
	public Menu() {
		b1 = new JButton("Run Simulation");
		b1.setVerticalTextPosition(AbstractButton.CENTER);
		b1.setHorizontalTextPosition(AbstractButton.CENTER);
		b1.setActionCommand("RUN");
		b1.setEnabled(true);
		b1.setToolTipText("Click this button to run the simulation.");
		
		b2 = new JButton("Show Controller");
		b2.setVerticalTextPosition(AbstractButton.CENTER);
		b2.setHorizontalTextPosition(AbstractButton.CENTER);
		b2.setActionCommand("showController");
		b1.setEnabled(true);
		b2.setToolTipText("Click this button to show the controller.");
		
		b3 = new JButton("Run Editor");
		b3.setVerticalTextPosition(AbstractButton.CENTER);
		b3.setHorizontalTextPosition(AbstractButton.CENTER);
		b3.setActionCommand("runEditor");
		b1.setEnabled(true);
		b3.setToolTipText("Click this button to run the editor.");
		
		b4 = new JButton("Show Stats");
		b4.setVerticalTextPosition(AbstractButton.CENTER);
		b4.setHorizontalTextPosition(AbstractButton.CENTER);
		b4.setActionCommand("showStats");
		b1.setEnabled(true);
		b4.setToolTipText("Click this button to show the statistics.");
		
		//Listen for the actions on all buttons.
		b1.addActionListener(this);
		
		add(b1);
		add(b2);
		add(b3);
		add(b4);
	}
	
	public void actionPerformed(ActionEvent e) {
		//"Run Simulation" is clicked.
		if("RUN".equals(e.getActionCommand()) && b1.isEnabled()) {
			s.runSimulation();
			b1.setEnabled(false);
		}
	}
	
	public void setupAndDisplay() {
        //Create and set up the window.
        JFrame f = new JFrame("Traffic Flow Simulator Menu");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(500, 500);
        f.setLocationRelativeTo(null);

        //Create and set up the content pane.
        Menu newContentPane = new Menu();
        newContentPane.setOpaque(true); //content panes must be opaque
        f.setContentPane(newContentPane);
        
        //Display the window.
        f.pack();
        f.setVisible(true);
	}
	
	public void run() {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                setupAndDisplay(); 
            }
        });
	}
}
