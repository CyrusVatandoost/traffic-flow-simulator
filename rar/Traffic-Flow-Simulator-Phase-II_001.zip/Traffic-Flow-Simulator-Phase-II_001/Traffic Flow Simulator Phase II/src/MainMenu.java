import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainMenu extends JFrame {

	private JPanel contentPane;
	private Menu m1 = new Menu();
	private EditorMenu m2 = new EditorMenu();
	/**
	 * Constructor method for Main Menu class
	 */
	public MainMenu() {
		setResizable(false);
		setEnabled(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTrafficFlowSimulator = new JLabel("Traffic Flow Simulator");
		lblTrafficFlowSimulator.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblTrafficFlowSimulator.setBounds(5, 5, 424, 50);
		lblTrafficFlowSimulator.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblTrafficFlowSimulator);
		
		JLabel lblNewLabel = new JLabel("Cyrus A. Vatandoost Kakhki");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(5, 211, 424, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblJuliusCeasarLibrada = new JLabel("Julius Ceasar Librada");
		lblJuliusCeasarLibrada.setHorizontalAlignment(SwingConstants.CENTER);
		lblJuliusCeasarLibrada.setBounds(5, 236, 424, 14);
		contentPane.add(lblJuliusCeasarLibrada);
		
		JButton btnNewButton = new JButton("Run Simulator");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				m1.run();
			}
		});
		btnNewButton.setBounds(5, 66, 204, 134);
		contentPane.add(btnNewButton);
		
		JButton btnRunLayoutManager = new JButton("Run Layout Manager");
		btnRunLayoutManager.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				m2.run();
			}
		});
		btnRunLayoutManager.setBounds(219, 66, 210, 134);
		contentPane.add(btnRunLayoutManager);
	}
	/**
	 * This method runs the simulation based on the input of the user
	 */
	public void run() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenu frame = new MainMenu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
