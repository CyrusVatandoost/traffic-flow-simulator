import java.io.IOException;

public class Driver {

	public static void main(String[] args) throws IOException {
		MainMenu m = new MainMenu();
		m.run();
	}
}
