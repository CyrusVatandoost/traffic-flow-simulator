import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import net.miginfocom.swing.MigLayout;
import java.awt.FlowLayout;
import javax.swing.JToggleButton;
import javax.swing.JSlider;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Insets;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JSpinner;
import javax.swing.JTree;
import javax.swing.SpinnerNumberModel;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;
import javax.swing.JTextField;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormSpecs;
import com.jgoodies.forms.layout.RowSpec;
import java.awt.CardLayout;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class Menu extends JFrame {

	private MainMenu mm;
	private JPanel contentPane;
	private Simulation s = new Simulation();
	private JTextField timeSpeedTextField;
	/**
	 * Constructor method for Menu class
	 */
	public Menu() {
		setTitle("Traffic Flow Simulator");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 250);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem mntmMap = new JMenuItem("Map 1");
		mntmMap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s.setMapName("map_001.txt");
			}
		});
		mnFile.add(mntmMap);
		
		JMenuItem mntmMap_1 = new JMenuItem("Map 2");
		mntmMap_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s.setMapName("map_002.txt");
			}
		});
		mnFile.add(mntmMap_1);
		
		JMenuItem mntmMap_2 = new JMenuItem("Map 3");
		mntmMap_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s.setMapName("map_003.txt");
			}
		});
		mnFile.add(mntmMap_2);
		
		JMenu mnEdit = new JMenu("Edit");
		menuBar.add(mnEdit);
		
		JMenuItem mntmStart = new JMenuItem("Start");
		mnEdit.add(mntmStart);
		
		JMenuItem mntmPause = new JMenuItem("Pause");
		mnEdit.add(mntmPause);
		
		JMenuItem mntmNextStep = new JMenuItem("Next Step");
		mnEdit.add(mntmNextStep);
		
		JMenuItem mntmDisplay = new JMenuItem("Display");
		mnEdit.add(mntmDisplay);
		
		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		
		JMenuItem mntmHelp = new JMenuItem("Help");
		mnHelp.add(mntmHelp);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setResizable(false);
		
		JButton startButton = new JButton("Start");
		startButton.setBounds(396, 12, 89, 23);
		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				s.setTimeSpeed(Integer.parseInt(timeSpeedTextField.getText()));
				s.runSimulation();
			}
		});
		
		JButton btnNewButton_1 = new JButton("Display");
		btnNewButton_1.setBounds(396, 114, 89, 23);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				s.displaySimulation();
			}
		});
		
		JButton btnNewButton = new JButton("Set Speed");
		btnNewButton.setBounds(10, 46, 89, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				s.setTimeSpeed(Integer.parseInt(timeSpeedTextField.getText()));
			}
		});
		
		JButton playPauseButton = new JButton("Pause");
		playPauseButton.setBounds(396, 46, 89, 23);
		playPauseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				s.togglePausePlay();
				if(s.getPause())
					playPauseButton.setText("Play");
				else
					playPauseButton.setText("Pause");
			}
		});
		
		JButton btnNextStep = new JButton("Next Step");
		btnNextStep.setBounds(396, 80, 89, 23);
		btnNextStep.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				s.nextStep();
			}
		});
		
		timeSpeedTextField = new JTextField();
		timeSpeedTextField.setBounds(109, 47, 89, 20);
		timeSpeedTextField.setText("100");
		timeSpeedTextField.setColumns(10);
		contentPane.setLayout(null);
		
		JLabel mapFileLabel = new JLabel("no file selected");
		mapFileLabel.setBounds(10, 16, 157, 14);
		contentPane.add(mapFileLabel);
		contentPane.add(startButton);
		contentPane.add(btnNewButton_1);
		contentPane.add(playPauseButton);
		contentPane.add(btnNextStep);
		contentPane.add(btnNewButton);
		contentPane.add(timeSpeedTextField);
		
		JButton btnMenu = new JButton("Menu");
		btnMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mm = new MainMenu();
				mm.run();
				dispose();
			}
		});
		btnMenu.setBounds(10, 166, 89, 23);
		contentPane.add(btnMenu);
		
		JButton btnStop = new JButton("Stop");
		btnStop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s.stopSimulation();
			}
		});
		btnStop.setBounds(396, 148, 89, 23);
		contentPane.add(btnStop);
	}
	/**
	 * This method runs the simulation based on the users input
	 */
	public void run() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
