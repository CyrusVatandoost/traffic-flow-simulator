import java.awt.Color;
import java.util.concurrent.ThreadLocalRandom;

public class Vehicle {
	protected int x;
	protected int y;
	protected int lastDirection;
	protected boolean hasMoved;
	protected boolean[] neighbor;
	protected int[] road;
	protected Color color;
	
	public Vehicle(int x, int y) {
		this.x = x;
		this.y = y;
		hasMoved = false;
		chooseColor();
	}

	public void chooseColor() {
		int num;
		
		num = ThreadLocalRandom.current().nextInt(0, 6);
		
		switch(num) {
		case 0:
			color = Color.CYAN;
			break;
		case 1:
			color = Color.ORANGE;
			break;
		case 2:
			color = Color.PINK;
			break;
		case 3:
			color = Color.GREEN;
			break;
		case 4:
			color = Color.MAGENTA;
			break;
		case 5:
			color = Color.BLUE;
			break;
		}
	}
	
	public void move(int direction) {
		
		switch(direction) {
		
		//If the direction is up, move up.
		case 0 :
			if(neighbor[0] == false) {
				y--;
				lastDirection = 0;
			}
			break;
		
		//If the direction is down, move down.
		case 1:
			if(neighbor[1] == false) {
				y++;
				lastDirection = 1;
			}
			break;
		
		//if the direction is left, move left.
		case 2:
			if(neighbor[2] == false) {
				x--;
				lastDirection = 2;
			}
			break;
			
		//If the direction is right, move right.
		case 3:
			if(neighbor[3] == false) {
				x++;
				lastDirection = 3;
			}
			break;
			
		//If the car is on an intersection, have fun.
		case 4:
			
			switch(lastDirection) {
				
			//If the car was from SOUTH, do this.
			case 0:
				if(road[0] != 1 && road[2] != 3 && road[3] != 2 && !neighbor[0] && !neighbor[2] && !neighbor[3])
					move(chooseNum(0, 2, 3));
				
				else if(road[0] != 1 && road[2] != 3 && !neighbor[0] && !neighbor[2])
					move(chooseNum(0, 2));
				else if(road[0] != 1 && road[3] != 2 && !neighbor[0] && !neighbor[3])
					move(chooseNum(0, 3));
				else if(road[2] != 3 && road[3] != 2 && !neighbor[2] && !neighbor[3])
					move(chooseNum(2, 3));
				
				else if((road[0] == 1 || neighbor[0]) && road[2] == 3 && (road[3] == 1 || neighbor[3]))
					move(3);
				else if((road[0] == 1 || neighbor[0]) && (road[2] == 1 || neighbor[2] || road[3] == 2))
					move(2);
				else if((road[0] == 0 && (road[2] == 1 || neighbor[2]) && (road[2] == 1 || neighbor[3])))
					move(0);
				
				else if(road[0] != 1 && !neighbor[0])
					move(0);
				else if(road[2] != 3 && !neighbor[2])
					move(2);
				else if(road[3] != 2 && !neighbor[3])
					move(3);
				
				break;
				
			//If the car was from NORTH, do this.
			case 1:
				if(road[1] != 0 && road[2] != 3 && road[3] != 2 && !neighbor[1] && !neighbor[2] && !neighbor[3])
					move(chooseNum(1, 2, 3));
				
				else if(road[1] != 0 && road[2] != 3 && !neighbor[1] && !neighbor[2])
					move(chooseNum(1, 2));
				else if(road[1] != 0 && road[3] != 2 && !neighbor[1] && !neighbor[3])
					move(chooseNum(1, 3));
				else if(road[2] != 3 && road[3] != 2 && !neighbor[2] && !neighbor[3])
					move(chooseNum(2, 3));
				
				else if((road[1] == 0 || !neighbor[1]) && road[2] == 3 && (road[3] == 2 || !neighbor[3]))
					move(3);
				else if((road[1] == 0 || !neighbor[1]) && (road[2] == 2 || !neighbor[2]) && road[3] == 2)
					move(2);
				else if(road[1] == 1 && (road[2] == 2 || !neighbor[2]) && (road[3] == 2 || !neighbor[3]))
					move(1);
				
				else if(road[1] != 0 && !neighbor[1])
					move(1);
				else if(road[2] != 3 && !neighbor[2])
					move(2);
				else if(road[3] != 2 && !neighbor[3])
					move(3);
				
				break;
				
			//If the car was from EAST, do this.
			case 2:
				if(road[0] != 1 && road[1] != 0 && road[2] != 3 && !neighbor[0] && !neighbor[1] && !neighbor[2])
					move(chooseNum(0, 1, 2));
				
				else if(road[0] != 1 && road[1] != 0 && !neighbor[0] && !neighbor[1])
					move(chooseNum(0, 1));
				else if(road[0] != 1 && road[2] != 3 && !neighbor[0] && !neighbor[2])
					move(chooseNum(0, 2));
				else if(road[1] != 0 && road[2] != 3 && !neighbor[1] && !neighbor[2])
					move(chooseNum(1, 2));
				
				else if((road[0] == 1 || !neighbor[0]) && (road[1] == 0 || !neighbor[1]) && road[2] == 2)
					move(2);
				else if((road[0] == 1 || !neighbor[0]) && road[1] == 1 && (road[2] == 3 || !neighbor[2]))
					move(1);
				else if(road[0] == 0 && (road[1] == 0 || !neighbor[1]) && (road[2] == 3 || !neighbor[2]))
					move(0);
				
				else if(road[0] != 1 && !neighbor[0])
					move(0);
				else if(road[1] != 0 && !neighbor[1])
					move(1);
				else if(road[2] != 3 && !neighbor[2])
					move(2);
				
				break;
				
			//If the car was from WEST, do this.
			case 3:
				if(road[0] != 1 && road[1] != 0 && road[3] != 2 && !neighbor[0] && !neighbor[1] && !neighbor[3])
					move(chooseNum(0, 1, 3));
				
				else if(road[0] != 1 && road[1] != 0 && !neighbor[0] && !neighbor[1])
					move(chooseNum(0, 1));
				else if(road[0] != 1 && road[3] != 2 && !neighbor[0] && !neighbor[3])
					move(chooseNum(0, 3));
				else if(road[1] != 0 && road[3] != 2 && !neighbor[1] && !neighbor[3])
					move(chooseNum(1, 3));
				
				else if((road[0] == 1 || !neighbor[0]) && (road[1] == 0 || !neighbor[1]) && road[3] == 3)
					move(3);
				else if(road[0] == 0 && (road[1] == 0 || !neighbor[1]) && (road[3] == 2 || !neighbor[3]))
					move(0);
				else if((road[0] == 1 || !neighbor[0]) && road[1] == 1 && (road[3] == 2 || !neighbor[3]))
					move(1);
				
				else if(road[0] != 1 && !neighbor[0])
					move(0);
				else if(road[1] != 0 && !neighbor[1])
					move(1);
				else if(road[3] != 2 && !neighbor[3])
					move(3);
					
				break;
			}
			
			break;
		}
		
	}
	
	public int chooseNum(int a, int b) {
		int rand;
		
		rand = ThreadLocalRandom.current().nextInt(1, 3);
		
		if(rand == 1)
			return a;
		else if(rand == 2)
			return b;
		return a;
	}
	
	public int chooseNum(int a, int b, int c) {
		int rand;
		
		rand = ThreadLocalRandom.current().nextInt(1, 4);
		
		if(rand == 1)
			return a;
		else if(rand == 2)
			return b;
		else if(rand == 3)
			return c;
		return a;
	}

	public void setHasMoved(boolean moved) {
		hasMoved = moved;
	}
	
	public void setNeighbors(boolean[] neighbor) {
		this.neighbor = neighbor;
	}
	
	public void setRoad(int[] road) {
		this.road = road;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public boolean getHasMoved() {
		return hasMoved;
	}
	
	public Color getColor() {
		return color;
	}
}
