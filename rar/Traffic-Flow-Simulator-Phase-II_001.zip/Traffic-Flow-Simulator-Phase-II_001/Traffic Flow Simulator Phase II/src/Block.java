
public class Block {
	private TrafficLight t;
	private boolean hasTrafficLight;
	/**
	 * this method sets a normal block
	 */
	public Block() {
		hasTrafficLight = false;
	}
	/**
	 * this method sets a traffic light block
	 * @param t - retrieves traffic light settings from TrafficLight class
	 */
	public void setTrafficLight(TrafficLight t) {
		this.t = t;
		hasTrafficLight = true;
	}
	/**
	 * this method returns traffic light settings
	 * @return traffic light settings
	 */
	public boolean getHasTrafficLight() {
		return hasTrafficLight;
	}
	/**
	 * this method returns a traffic light block
	 * @return traffic light block
	 */
	public TrafficLight getTrafficLight() {
		return t;
	}
}
