import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.swing.JFrame;

public class EditorModel extends Thread{
	private String mapName;
	
	private int width;
	private int height;
	
	private ArrayList <Wall> wallList;
	private ArrayList <Spawner> spawnerList;
	private ArrayList <Road> roadList;
	private ArrayList <DropOff> dropOffList;
	private ArrayList <TrafficLight> trafficLightList;
	
	private int[][] map;
	private int[][] objectMap;
	private Block[][] block;

	private JFrame f;
	
	private int mouseX;
	private int mouseY;
	
	public EditorModel() {

	}
	/**
	 * This method checks if a button is clicked
	 * @param e - event when a button is clicked
	 */
	public void mouseClicked(MouseEvent e) {
	    int x = e.getX();
	    int y = e.getY();
	    System.out.println(x+","+y);//these co-ords are relative to the component
	}
	/**
	 * This method saves the alerations the user made to the map
	 */
	public void save() throws FileNotFoundException, UnsupportedEncodingException {
		convertToMap();
		Printer p = new Printer(this);
		p.setMapName(mapName);
		p.print();
	}
	/**
	 * This method lets the user choose a map
	 */
	public void setMap() {
		Reader r = new Reader();
		
		try {
			r.read(mapName);
		} catch (IOException e1) {
			System.out.println("ERROR!");
			e1.printStackTrace();
		}
		
		int i, x, y, direction;
		
		width = r.getWidth();
		height = r.getHeight();
		
		//This gets the values of the different entities from the text file.
		wallList = new ArrayList <Wall> (r.getWallList());
		spawnerList = new ArrayList <Spawner> (r.getSpawnerList());
		roadList = new ArrayList <Road> (r.getRoadList());
		dropOffList = new ArrayList <DropOff> (r.getdropOffList());
		trafficLightList = new ArrayList <TrafficLight> (r.getTrafficLightList());
		
		map = new int[width][height];
		objectMap = new int[width][height];
		block = new Block[width][height];
		
		//This clears the map.
		for(x = 0; x < width; x++) {
			for(y = 0; y < height; y++) {
				map[x][y] = 0;
				objectMap[x][y] = 0;
				block[x][y] = new Block();
			}
		}
		
		//This adds walls into the map.
		for(i = 0; i < wallList.size(); i++) {
			x = wallList.get(i).getX();
			y = wallList.get(i).getY();
			
			map[x][y] = 9;
			objectMap[x][y] = 9;
		}
		
		//This adds roads into the map.
		for(i = 0; i < roadList.size(); i++) {
			x = roadList.get(i).getX();
			y = roadList.get(i).getY();
			direction = roadList.get(i).getDirection();
			
			map[x][y] = direction;
		}
		
		//This adds traffic lights into the map.
		for(i = 0; i < trafficLightList.size(); i++) {
			x = trafficLightList.get(i).getX();
			y = trafficLightList.get(i).getY();
			
			block[x][y].setTrafficLight(trafficLightList.get(i));;
		}
	}
	/**
	 * This method sets the area of the display
	 * @param width - width of the simulation
	 * @param height - height of the simulation
	 */
	public void setDisplay(int width, int height) {
		f = new JFrame("Map Editor");
		f.setSize(width, height);
		f.setLocationRelativeTo(null);
		f.getContentPane().add(new EditorDisplay(this));
		f.setVisible(true);
	}
	/**
	 * This method displays the simulation
	 */
	public void displayMap() {
		
		Thread t = new Thread() {
			public void run() {
				setDisplay(500, 500);
			}
		};
		
		t.start();
	}
	/**
	 * This method lets the user erase all elements of the simulation
	 */
	public void deleteAll() {
		wallList = null;
		spawnerList = null;
		roadList = null;
		dropOffList = null;
		trafficLightList = null;
		
		map = null;
		objectMap = null;
		block = null;
	}
	/**
	 * This method lets the user change from one map to another
	 */
	public void convertToMap() {
		int i, x, y;
		
		for(y = 0; y < height; y++) {
			for(x = 0; x < width; x++) {
				map[x][y] = 9;
			}
		}
		
		for(i = 0; i < roadList.size(); i++) {
			x = roadList.get(i).getX();
			y = roadList.get(i).getY();
			
			map[x][y] = roadList.get(i).getDirection();
		}
	}
	/**
	 * This method sets a map name
	 * @param mapName - name of the map
	 */
	public void setMapName(String mapName) {
		this.mapName = mapName;
	}
	/**
	 * This method lets the user add a road block
	 * @param x - x coordinate where the user wants to place the road
	 * @param y - y coordinate where the user  wants to place the road
	 * @param direction - the direction the road is assigned to
	 */
	public void addRoad(int x, int y, int direction) {
		int i, x1, y1, x2, y2;
		
		for(i = 0; i < roadList.size(); i++) {
			x2 = roadList.get(i).getX();
			y2 = roadList.get(i).getY();
			
			if(x == x2 && y == y2)
				roadList.remove(i);
		}
		
		Road r = new Road(x, y, direction);
		
		x1 = r.getX();
		y1 = r.getY();
		
		for(i = 0; i < wallList.size(); i++) {
			x2 = wallList.get(i).getX();
			y2 = wallList.get(i).getY();
			
			if(x1 == x2 && y1 == y2)
				wallList.remove(i);
		}
		
		roadList.add(r);
		r = null;
	}
	/**
	 * This method lets the user add a wall
	 * @param x - x coordinate where the user wants to place the wall
	 * @param y - y coordinate where the user wants to place the wall
	 */
	public void addWall(int x, int y) {
		int i, x1, y1, x2, y2;
		
		for(i = 0; i < wallList.size(); i++) {
			x2 = wallList.get(i).getX();
			y2 = wallList.get(i).getY();
			
			if(x == x2 && y == y2)
				wallList.remove(i);
		}
		
		Wall w = new Wall(x, y);
		
		for(i = 0; i < roadList.size(); i++) {
			x2 = roadList.get(i).getX();
			y2 = roadList.get(i).getY();
			
			if(x == x2 && y == y2)
				roadList.remove(i);
		}
		
		wallList.add(w);
		w = null;
	}
	/**
	 * This method lets the user add a spawner to the simulation
	 * @param x - x coordinate where the user wants to place the spawner
	 * @param y - y coordinate where the user wants to place the spawner
	 * @param rate - rate at which cars spawn
	 */
	public void addSpawner(int x, int y, int rate) {
		int i, x1, y1;
		
		for(i = 0; i < spawnerList.size(); i++) {
			x1 = spawnerList.get(i).getX();
			y1 = spawnerList.get(i).getY();
			
			if(x == x1 && y == y1)
				spawnerList.remove(i);
		}
		
		Spawner s = new Spawner(x, y, rate);
		spawnerList.add(s);
		s = null;
	}
	/**
	 * This method lets the user add a Traffic Light block
	 * @param x - x coordinate where the user wants to add the Traffic Light
	 * @param y - y coordinate where the user wants to add the Traffic Light
	 * @param rate - rate at which the color of the Traffic Light changes
	 * @param start - time when the simulation started
	 */
	public void addTrafficLight(int x, int y, int rate, int start) {
		int i, x1, y1;
		
		for(i = 0; i < trafficLightList.size(); i++) {
			x1 = trafficLightList.get(i).getX();
			y1 = trafficLightList.get(i).getY();
			
			if(x == x1 && y == y1)
				trafficLightList.remove(i);
		}
		
		TrafficLight t = new TrafficLight(x, y, rate, start);
		trafficLightList.add(t);
		t = null;
	}
	/**
	 * This method returns the width of the simulator
	 * @return width of the simulator
	 */
	public int getWidth() {
		return width;
	}
	/**
	 * This method returns the height of the simulator
	 * @return the height of the simulator
	 */
	public int getHeight() {
		return height;
	}
	/**
	 * This method returns the map
	 * @return structure of the map
	 */
	public int[][] getMap() {
		return map;
	}
	/**
	 * This method returns all the coordinates of the walls
	 * @return the coordinates of the walls
	 */
	public ArrayList <Wall> getWallList() {
		return wallList;
	}
	/**
	 * This method returns all the coordinate of the spawners
	 * @return the coordinates of the spawners
	 */
	public ArrayList <Spawner> getSpawnerList() {
		return spawnerList;
	}
	/**
	 * This method returns the coordinates of all the roads
	 * @return the coordinates of the roads
	 */
	public ArrayList <Road> getRoadList() {
		return roadList;
	}
	/**
	 * This method returns the coordinates of all the Drop Off blocks
	 * @return the coordinates of the Drop Off blocks
	 */
	public ArrayList <DropOff> getDropOffList() {
		return dropOffList;
	}
	/**
	 * This method returns the coordinates of all the Traffic Light blocks
	 * @return the coordinates of the Traffic Light blocks
	 */
	public ArrayList <TrafficLight> getTrafficLightList() {
		return trafficLightList;
	}
}