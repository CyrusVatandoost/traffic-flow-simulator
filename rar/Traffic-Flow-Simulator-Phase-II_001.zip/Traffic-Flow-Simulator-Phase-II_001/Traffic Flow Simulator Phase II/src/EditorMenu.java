import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JToolBar;
import javax.swing.JInternalFrame;
import javax.swing.JDesktopPane;
import javax.swing.JFileChooser;
import javax.swing.JToggleButton;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;

public class EditorMenu extends JFrame{

	private JPanel contentPane;
	private String mapName;
	
	EditorModel m = new EditorModel();
	MainMenu mm;

	private JTextField roadX;
	private JTextField roadDirection;
	private JTextField wallY;
	private JTextField wallX;
	private JTextField roadY;
	private JTextField spawnerX;
	private JTextField spawnerY;
	private JTextField spawnerRate;
	private JTextField trafficLightX;
	private JTextField trafficLightY;
	private JTextField trafficLightRate;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	/**
	 * Constructor method for EditorMenu class
	 */
	public EditorMenu() {
		setResizable(false);
		setTitle("Editor Menu");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel message = new JLabel("");
		message.setBounds(10, 546, 669, 14);
		contentPane.add(message);
		
		JLabel mapNameLabel = new JLabel("no file selected");
		mapNameLabel.setBounds(10, 32, 87, 14);
		contentPane.add(mapNameLabel);
		
		JButton addRoad = new JButton("Add");
		addRoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m.addRoad(Integer.parseInt(roadX.getText()), Integer.parseInt(roadY.getText()), Integer.parseInt(roadDirection.getText()));
			}
		});
		addRoad.setBounds(205, 157, 86, 23);
		contentPane.add(addRoad);
		
		JButton addWall = new JButton("Add");
		addWall.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m.addWall(Integer.parseInt(wallX.getText()), Integer.parseInt(wallY.getText()));
			}
		});
		addWall.setBounds(397, 125, 86, 23);
		contentPane.add(addWall);
		
		JButton addSpawner = new JButton("Add");
		addSpawner.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m.addSpawner(Integer.parseInt(spawnerX.getText()), Integer.parseInt(spawnerY.getText()), Integer.parseInt(spawnerRate.getText()));
			}
		});
		addSpawner.setBounds(593, 157, 86, 23);
		contentPane.add(addSpawner);
		
		JButton trafficLightStart = new JButton("Go");
		trafficLightStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(trafficLightStart.getText() == "Go")
					trafficLightStart.setText("Stop");
				else
					trafficLightStart.setText("Go");
			}
		});
		trafficLightStart.setBounds(397, 309, 86, 23);
		contentPane.add(trafficLightStart);
		
		JButton addTrafficLight = new JButton("Add");
		addTrafficLight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(trafficLightStart.getText() == "Go")
					m.addTrafficLight(Integer.parseInt(trafficLightX.getText()), Integer.parseInt(trafficLightY.getText()), Integer.parseInt(trafficLightRate.getText()), 0);
				else
					m.addTrafficLight(Integer.parseInt(trafficLightX.getText()), Integer.parseInt(trafficLightY.getText()), Integer.parseInt(trafficLightRate.getText()), 1);
			}
		});
		addTrafficLight.setBounds(397, 343, 86, 23);
		contentPane.add(addTrafficLight);
		
		JLabel lblAddRoad = new JLabel("Add Road");
		lblAddRoad.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddRoad.setBounds(205, 32, 86, 14);
		contentPane.add(lblAddRoad);
		
		JLabel lblAddSpawner = new JLabel("Add Spawner");
		lblAddSpawner.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddSpawner.setBounds(593, 32, 86, 14);
		contentPane.add(lblAddSpawner);
		
		JLabel lblAddWall = new JLabel("Add Wall");
		lblAddWall.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddWall.setBounds(397, 32, 88, 14);
		contentPane.add(lblAddWall);
		
		JLabel lblAddDropOff = new JLabel("Add Drop Off Point");
		lblAddDropOff.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddDropOff.setBounds(193, 191, 118, 14);
		contentPane.add(lblAddDropOff);
		
		JLabel lblAddTrafficLight = new JLabel("Add Traffic Light");
		lblAddTrafficLight.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddTrafficLight.setBounds(397, 191, 88, 14);
		contentPane.add(lblAddTrafficLight);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 97, 21);
		contentPane.add(menuBar);
		
		JMenu mnTools = new JMenu("File");
		menuBar.add(mnTools);
		
		JButton btnRun = new JButton("Scan");
		btnRun.setEnabled(false);
		btnRun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m.setMapName(mapName);
				m.setMap();
			}
		});
		
		JMenuItem map1MB = new JMenuItem("Map 1");
		map1MB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mapNameLabel.setText("map_001.txt");
				mapName = mapNameLabel.getText();
				message.setText("map_001.txt selected");
				btnRun.setEnabled(true);
			}
		});
		
		JMenuItem mntmSave = new JMenuItem("Save");
		mntmSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					m.save();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (UnsupportedEncodingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		mnTools.add(mntmSave);
		mnTools.add(map1MB);
		
		JMenuItem map2MB = new JMenuItem("Map 2");
		map2MB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mapNameLabel.setText("map_002.txt");
				mapName = mapNameLabel.getText();
				message.setText("map_002.txt selected");
				btnRun.setEnabled(true);
			}
		});
		mnTools.add(map2MB);
		
		JMenuItem map3MB = new JMenuItem("Map 3");
		map3MB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mapNameLabel.setText("map_003.txt");
				mapName = mapNameLabel.getText();
				message.setText("map_003.txt selected");
				btnRun.setEnabled(true);
			}
		});
		mnTools.add(map3MB);
		
		JMenu mnEdit = new JMenu("Edit");
		menuBar.add(mnEdit);
		
		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		
		JButton btnDisplay = new JButton("Display");
		btnDisplay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m.displayMap();
			}
		});
		

		btnRun.setBounds(10, 57, 89, 23);
		contentPane.add(btnRun);
		btnDisplay.setBounds(10, 91, 89, 23);
		contentPane.add(btnDisplay);
		
		roadX = new JTextField();
		roadX.setBounds(205, 58, 86, 20);
		contentPane.add(roadX);
		roadX.setColumns(10);
		
		roadDirection = new JTextField();
		roadDirection.setBounds(205, 126, 86, 20);
		contentPane.add(roadDirection);
		roadDirection.setColumns(10);
		
		wallY = new JTextField();
		wallY.setBounds(397, 92, 86, 20);
		contentPane.add(wallY);
		wallY.setColumns(10);
		
		wallX = new JTextField();
		wallX.setBounds(397, 58, 86, 20);
		contentPane.add(wallX);
		wallX.setColumns(10);
		
		JLabel lblY = new JLabel("y");
		lblY.setHorizontalAlignment(SwingConstants.RIGHT);
		lblY.setBounds(109, 91, 86, 23);
		contentPane.add(lblY);
		
		JButton btnDelete = new JButton("Clear");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m.deleteAll();
			}
		});
		btnDelete.setBounds(10, 157, 89, 23);
		contentPane.add(btnDelete);
		
		roadY = new JTextField();
		roadY.setBounds(205, 92, 86, 20);
		contentPane.add(roadY);
		roadY.setColumns(10);
		
		JLabel lblX = new JLabel("x");
		lblX.setHorizontalAlignment(SwingConstants.RIGHT);
		lblX.setBounds(109, 57, 86, 23);
		contentPane.add(lblX);
		
		JLabel lblDirection = new JLabel("direction");
		lblDirection.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDirection.setBounds(107, 125, 86, 23);
		contentPane.add(lblDirection);
		
		JLabel label = new JLabel("x");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(301, 57, 86, 23);
		contentPane.add(label);
		
		JLabel lblY_1 = new JLabel("y");
		lblY_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblY_1.setBounds(301, 91, 86, 23);
		contentPane.add(lblY_1);
		
		spawnerX = new JTextField();
		spawnerX.setColumns(10);
		spawnerX.setBounds(593, 58, 86, 20);
		contentPane.add(spawnerX);
		
		spawnerY = new JTextField();
		spawnerY.setColumns(10);
		spawnerY.setBounds(593, 92, 86, 20);
		contentPane.add(spawnerY);
		
		JLabel label_1 = new JLabel("x");
		label_1.setHorizontalAlignment(SwingConstants.RIGHT);
		label_1.setBounds(497, 57, 86, 23);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("y");
		label_2.setHorizontalAlignment(SwingConstants.RIGHT);
		label_2.setBounds(497, 91, 86, 23);
		contentPane.add(label_2);
		
		spawnerRate = new JTextField();
		spawnerRate.setColumns(10);
		spawnerRate.setBounds(593, 126, 86, 20);
		contentPane.add(spawnerRate);
		
		JLabel lblRate = new JLabel("rate");
		lblRate.setHorizontalAlignment(SwingConstants.RIGHT);
		lblRate.setBounds(497, 126, 86, 23);
		contentPane.add(lblRate);
		
		trafficLightX = new JTextField();
		trafficLightX.setColumns(10);
		trafficLightX.setBounds(397, 216, 86, 20);
		contentPane.add(trafficLightX);
		
		trafficLightY = new JTextField();
		trafficLightY.setColumns(10);
		trafficLightY.setBounds(397, 247, 86, 20);
		contentPane.add(trafficLightY);
		
		JLabel label_3 = new JLabel("x");
		label_3.setHorizontalAlignment(SwingConstants.RIGHT);
		label_3.setBounds(301, 216, 86, 23);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("y");
		label_4.setHorizontalAlignment(SwingConstants.RIGHT);
		label_4.setBounds(301, 250, 86, 23);
		contentPane.add(label_4);
		
		trafficLightRate = new JTextField();
		trafficLightRate.setColumns(10);
		trafficLightRate.setBounds(397, 278, 86, 20);
		contentPane.add(trafficLightRate);
		
		JLabel lblRate_1 = new JLabel("rate");
		lblRate_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblRate_1.setBounds(301, 278, 86, 23);
		contentPane.add(lblRate_1);
		
		JLabel lblStart = new JLabel("start");
		lblStart.setHorizontalAlignment(SwingConstants.RIGHT);
		lblStart.setBounds(301, 309, 86, 23);
		contentPane.add(lblStart);
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		textField_9.setBounds(205, 216, 86, 20);
		contentPane.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(205, 247, 86, 20);
		contentPane.add(textField_10);
		
		textField_11 = new JTextField();
		textField_11.setColumns(10);
		textField_11.setBounds(205, 278, 86, 20);
		contentPane.add(textField_11);
		
		JLabel label_5 = new JLabel("x");
		label_5.setHorizontalAlignment(SwingConstants.RIGHT);
		label_5.setBounds(109, 216, 86, 23);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("y");
		label_6.setHorizontalAlignment(SwingConstants.RIGHT);
		label_6.setBounds(109, 247, 86, 23);
		contentPane.add(label_6);
		
		JButton btnMenu = new JButton("Menu");
		btnMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mm = new MainMenu();
				mm.run();
				dispose();
			}
		});
		btnMenu.setBounds(10, 512, 89, 23);
		contentPane.add(btnMenu);
		
		JButton btnNew = new JButton("New");
		btnNew.setBounds(10, 125, 89, 23);
		contentPane.add(btnNew);
		contentPane.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{message, mapNameLabel, addWall, addSpawner, lblAddDropOff, trafficLightStart, addRoad, addTrafficLight, lblAddRoad, lblAddSpawner, lblAddWall, lblAddTrafficLight, menuBar, mnTools, mntmSave, map1MB, map2MB, map3MB, mnEdit, mnHelp, btnRun, btnDisplay, roadX, roadDirection, wallY, wallX, lblY, btnDelete, roadY, lblX, lblDirection, label, lblY_1, spawnerX, spawnerY, label_1, label_2, spawnerRate, lblRate, trafficLightX, trafficLightY, label_3, label_4, trafficLightRate, lblRate_1, lblStart, textField_9, textField_10, textField_11, label_5, label_6, btnMenu, btnNew}));
	}
	/**
	 * This method lets the user edit elements of the traffic simulation
	 */
	public void run() {
		EventQueue.invokeLater(new Runnable() {
		public void run() {
			try {
				EditorMenu frame = new EditorMenu();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	});
	}
}
