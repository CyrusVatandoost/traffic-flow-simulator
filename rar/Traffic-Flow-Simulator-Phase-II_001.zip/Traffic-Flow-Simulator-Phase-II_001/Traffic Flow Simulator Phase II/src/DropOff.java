
public class DropOff {
	private int x;
	private int y;
	private int rate;
	private int time;
	private boolean occupied;
	/**
	 * This method sets a Drop Off block
	 * @param x - x coordinate of the block
	 * @param y - y coordinate of the block
	 * @param rate - time the vehicle has to drop off
	 */
	public DropOff(int x, int y, int rate) {
		this.x = x;
		this.y = y;
		this.rate = rate;
	}
}
