import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

public class Printer {
	private int width;
	private int height;
	private int[][] map;
	
	private ArrayList <Wall> wallList;
	private ArrayList <Spawner> spawnerList;
	private ArrayList <Road> roadList;
	private ArrayList <DropOff> dropOffList;
	private ArrayList <TrafficLight> trafficLightList;
	
	private String mapName;
	private EditorModel m;
	/**
	 * Constructor method for Printer class
	 * @param m settings from EditorModel class
	 * @throws FileNotFoundException
	 * @throws UnsupportedEncodingException
	 */
	public Printer(EditorModel m) throws FileNotFoundException, UnsupportedEncodingException {
		this.m = m;
	}
	/**
	 * This method prints the list of elements of the simulation
	 * @throws FileNotFoundException
	 * @throws UnsupportedEncodingException
	 */
	public void print() throws FileNotFoundException, UnsupportedEncodingException {
		int i, x, y;
		
		copy();
	
		PrintWriter p = new PrintWriter(mapName, "UTF-8");
		
		p.println(width);
		p.println(height);
		
		for(y = 0; y < height; y++) {
			for(x = 0; x < width; x++) {
				p.print(map[x][y]);
			}
			p.println();
		}
		
		for(i = 0; i < trafficLightList.size(); i++) {
			p.println("6");
			p.println(trafficLightList.get(i).getX());
			p.println(trafficLightList.get(i).getY());
			p.println(trafficLightList.get(i).getRate());
			p.println(trafficLightList.get(i).getStart());
		}
		
		for(i = 0; i < dropOffList.size(); i++) {
			;;
		}
		
		for(i = 0; i < spawnerList.size(); i++) {
			p.println("8");
			p.println(spawnerList.get(i).getX());
			p.println(spawnerList.get(i).getY());
			p.print(spawnerList.get(i).getRate());
			p.println();
		}
		
		p.close();
	}
	/**
	 * This method lets the user duplicate a map
	 */
	public void copy() {
		width = m.getWidth();
		height = m.getHeight();
		map = m.getMap();
		spawnerList = new ArrayList <Spawner> (m.getSpawnerList());
		dropOffList = new ArrayList <DropOff> (m.getDropOffList());
		trafficLightList = new ArrayList <TrafficLight> (m.getTrafficLightList());
	}
	/**
	 * This method sets a map name
	 * @param mapName name of the map
	 */
	public void setMapName(String mapName) {
		this.mapName = mapName;
	}
}
